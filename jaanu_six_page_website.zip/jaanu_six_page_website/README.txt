FOR JAANU — SIX-PAGE ROMANTIC WEBSITE

Files:
- index.html: password page
- home.html: welcome page
- letter1.html: your first letter (kept as supplied)
- letter2.html: your second letter (kept as supplied)
- memories.html: photo scrapbook
- music.html: song player (choose your own audio file)
- surprise.html: yes/no surprise
- style.css and script.js: shared design and behaviour

Password: 2512 (25 December, DDMM).

PREVIEW:
Extract the ZIP and open index.html in a browser. Enter 2512.

PUBLISH FREE:
1. Create a free GitHub account and a new PUBLIC repository.
2. Upload every file in this folder to the repository root.
3. Go to Settings > Pages.
4. Select Deploy from a branch, choose main and /(root), then Save.
5. GitHub Pages will give you a free shareable website address.

PERSONALISE:
- To include photos permanently, upload the image files to the repository and edit memories.html to use <img src="your-photo.jpg">.
- To include the song permanently, add an MP3 you have permission to use to the repository and change the audio section in music.html to <audio controls src="your-song.mp3"></audio>.
- The password is a cute front-end gate, not secure private access. Anyone with the website files can inspect the code.
- The site uses a session flag after unlocking; close the browser tab/session to reset it.
