const SECRET_CODE="2512"; // 25 December, DDMM
let entered="";
function update(){const el=document.getElementById("display");if(el)el.textContent=entered.padEnd(4,"•").split("").join(" ")}
function press(n){if(entered.length<4){entered+=n;update();if(entered.length===4)setTimeout(unlock,220)}}
function clearCode(){entered="";update();const e=document.getElementById("error");if(e)e.textContent=""}
function unlock(){if(entered===SECRET_CODE){sessionStorage.setItem("jaanuUnlocked","yes");location.href="home.html"}else{const e=document.getElementById("error");if(e)e.textContent="Oops! Try again, cutie 💗";entered="";update()}}
function yes(){const a=document.getElementById("answer");if(a)a.textContent="Surprise! You are my favourite blessing. I’m so lucky to have you in my life. Love you loads! 💗✨"}
function nope(){const a=document.getElementById("answer");if(a)a.textContent="Too late, the surprise is that you're amazing and that's final! 😄💞"}
const photos=document.getElementById("photos");
if(photos)photos.addEventListener("change",e=>{const g=document.getElementById("gallery");g.innerHTML="";[...e.target.files].forEach((f,i)=>{const card=document.createElement("div");card.className="photo";const img=document.createElement("img");img.src=URL.createObjectURL(f);const cap=document.createElement("small");cap.textContent=["A lovely memory","My favourite smile","A moment to keep"][i%3];card.append(img,cap);g.append(card)})});
const song=document.getElementById("songFile");
if(song)song.addEventListener("change",e=>{const f=e.target.files[0];if(f)document.getElementById("player").src=URL.createObjectURL(f)});
